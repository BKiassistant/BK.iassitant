# BK.iassistant

Your assistant with 24/7 service.

## Cómo usar
1. Configura las variables de entorno (.env).
2. Instala dependencias con `npm install`.
3. Ejecuta `npm run dev` para desarrollo.

Despliegue recomendado: [Vercel](https://vercel.com).
