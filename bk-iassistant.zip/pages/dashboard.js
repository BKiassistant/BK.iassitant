import { useState } from 'react';

export default function Dashboard() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  const sendMessage = async () => {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setMessages([...messages, { role: 'user', content: input }, { role: 'assistant', content: data.reply }]);
    setInput('');
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Tu asistente</h1>
      <div className="mt-4 border p-4 rounded-lg h-96 overflow-y-auto">
        {messages.map((msg, i) => (
          <p key={i}><b>{msg.role}:</b> {msg.content}</p>
        ))}
      </div>
      <div className="mt-4 flex">
        <input className="flex-1 border p-2 rounded-l" value={input} onChange={e => setInput(e.target.value)} />
        <button className="bg-blue-600 text-white px-4 rounded-r" onClick={sendMessage}>Enviar</button>
      </div>
    </div>
  );
}